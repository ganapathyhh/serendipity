</div>
<div id="footer">	
			<div class="copy">&copy; <?php echo WEBSITE_TITLE.' '. date('Y');?> </div>
	</div><?php //close footer ?>
</div>
</body>
</html>