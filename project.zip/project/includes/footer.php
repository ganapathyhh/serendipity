<script>
$('#like-button').click(function(){
    $.ajax({
        url: 'pagelidi.php',
        data: 
    });
});
$('#dislike-button').click(function(){
    
});
</script>