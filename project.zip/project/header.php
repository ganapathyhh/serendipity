<html>
    <head>
        <link href = "css/style.css" rel = "stylesheet"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    </head>
    <body>
    <div id="wrapper">

	<div id="logo"><a href="#"><?php echo WEBSITE_TITLE; ?></a></div>
	<div id="content">