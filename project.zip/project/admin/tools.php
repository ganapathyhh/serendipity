<?php
$current = "Tools";
require_once 'header.php';
?>
<h3>Tools</h3>
<?php
require_once 'footer.php';
?>