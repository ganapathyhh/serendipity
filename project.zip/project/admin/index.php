<?php
$current = "Home";
include 'header.php';
updateFirstTime($_SESSION['ID']);
?>

                    <h3>Welcome to serendipity version 1.0</h3>
                  <div>
                      <h3>Native Fonts</h3>

This dashboard now takes advantage of the fonts you already have, making it load faster and letting you feel more at home on whatever device you use.
                </div>
                    
                  <div>
                      <h3>Multisite, now faster than ever</h3>

Cached and comprehensive site queries improve your network admin experience.
                  </div>
    
<?php include 'footer.php';?>
    